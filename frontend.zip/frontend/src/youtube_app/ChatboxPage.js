import React from 'react';

function ChatboxPage() {
  return (
    <div>
      <h1>AI Chatbox</h1>
      <p>This is where you can interact with the AI model.</p>
    </div>
  );
}

export default ChatboxPage;